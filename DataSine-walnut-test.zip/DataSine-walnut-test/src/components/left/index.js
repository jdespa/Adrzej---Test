import React from 'react'

const Left = (props) => (
    <aside className="banner__left">
        {props.children}
    </aside>
)

export default Left
