import React, { useState } from 'react'
import image from '../../image.json'

const Tags = (props) => {

    const [hidden, setHidden] = useState(props.more)

    const num = n => (n * 100).toFixed(2)
    const tagsController = (data) => {
        const newImageOrder = data.map(x => ({ name: x.name, strength: Number((x.strength * 100).toFixed(2)) }))
            .sort((a, b) => Number(num(a.strength)) - Number(num(b.strength))).reverse()
        return newImageOrder
    }

    // const [dataTags, setDataTags] = useState(tagsController(image.tags))

    return (
        <div className={`${props.card} content content__wrap`}>
            <div className="panel content content__column">
                <h5>Image tags</h5>
                <div className="content content__justified content__wrap">
                    {hidden ?
                        (tagsController(image.tags).map(x => (<div key={x.strength} className="tag">{x.name}</div>))) :
                        (tagsController(image.tags).map((x, i) => {
                            if (i < 6) {
                                return (<div key={x.strength} className="tag">{x.name}</div>)
                            }
                        }))
                    }
                </div>
                {hidden ? (
                    <a onClick={() => setHidden(false)}><div className="arrow-up"></div></a>
                ) : (
                        <a onClick={() => setHidden(true)}><div className="arrow-down"></div></a>
                    )}
            </div>
        </div>
    )
}

export default Tags
