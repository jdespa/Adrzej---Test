import React from 'react'
import image from '../../image.json'

const Image = () => (
    <div className="panel">
        <img className="image" src={image.location} alt={image.name} />
    </div>
)

export default Image
