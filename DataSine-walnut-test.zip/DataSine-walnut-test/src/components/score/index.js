import React from 'react'
import image from '../../image.json'

const num = n => `${(n * 100).toFixed(2)}%`

const Score = () => (
    <div className="card content content__wrap">
        <div className="panel content content__column">
            <h5>Image tags</h5>
            <div className="content content__justified content__wrap">
                <div className="circle"></div>
                <p className="figure">{num(image.score)}</p>
            </div>
        </div>
    </div>
)

export default Score
