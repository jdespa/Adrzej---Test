import React from 'react'
import Header from '../header'
import Tags from '../tags'
import BannerRight from '../banner-right'
import Image from '../image'
import Score from '../score'
import Left from '../left'
import './styles.scss'

const App = () => {
    return (
        <div className="app">
            <Header />

            <div className="container info content content__row">
                <Left>
                    <Tags more={true} card={''} />
                </Left>

                <section className="banner__right content content__wrap">
                    <article className="w70">
                        <div className="content content__wrap">

                            <Tags more={false} card={'card'} />

                            <Score />
                        </div>
                        <Image />
                    </article>
                    <BannerRight />
                </section>
            </div>
        </div >
    )
}


export default App
