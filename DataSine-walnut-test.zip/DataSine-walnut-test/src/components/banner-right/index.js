import React from 'react'
import image from '../../image.json'

const data = Object.keys(image)
    .filter(x => x === 'texture' || x === 'composition' || x === 'colour')
    .map(x => {
        return (
            <div key={x}>
                <h5>{x}</h5>
                {Object.entries(image[x]).map(([key, value], i) => {
                    return (<p key={key} className="tag small">{[key]} {(Number(value) * 100).toFixed(2)}%</p>)
                })}
            </div>
        )
    })

const BannerRight = () => {
    return (
        <aside className="w30">
            <div className="panel content content__column">
                {data}
            </div>
        </aside>
    )
}

export default BannerRight
