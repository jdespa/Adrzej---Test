import React from 'react'

const Header = () => {
    return (
        <div className="navbar mb-20">
            <div className="container ">
                <h1>Walnut</h1>
            </div>
        </div>
    )
}

export default Header
