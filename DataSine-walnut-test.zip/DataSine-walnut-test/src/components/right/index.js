import React from 'react'

const Right = () => { }

export default Right
